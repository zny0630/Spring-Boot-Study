package com.soft1721.jianyue.api.entity.vo;

import lombok.Data;

@Data
public class FollowVO {
    private Integer toUId;
    private String nickname;
    private String avatar;
}
