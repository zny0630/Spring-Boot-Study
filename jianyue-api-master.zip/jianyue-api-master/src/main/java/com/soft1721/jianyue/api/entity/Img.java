package com.soft1721.jianyue.api.entity;

import lombok.Data;

import java.util.List;

@Data
public class Img {
    private Integer id;
    private Integer aId;
    private String imgUrl;
}