package com.soft1721.jianyue.api.entity;

import lombok.Data;


@Data

public class Like {

    private Integer id;

    private Integer uId;

    private Integer aId;

}