package com.soft1721.jianyue.api.entity.dto;

import lombok.Data;

/**
 * Created by 张楠燕 on 2019/4/1.
 */
@Data
public class UserDTO {
    private String mobile;
    private String password;
}
